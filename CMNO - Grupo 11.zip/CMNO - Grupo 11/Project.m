%% CMNO PROJECT - Group 11 

clear;
clc;
load('Apoio/fp_lin_matrices_fit3.mat');    % Load matrices A, B, C and D

%% Q1 - Characterization of the model
fprintf('A=\n'), disp(A);
fprintf('\n1. System Poles\n')
eigenvalues_A = eig(A);
damp(A)

%% Q2 - Controllability
fprintf('\n2. Controllability\n\n')
control_matrix = ctrb(A,B);
rank_control_matrix = rank(control_matrix);
n = size(A,1);
disp('Controllability Matrix:');
disp(control_matrix);

fprintf('Rank of Controllability Matrix: %d\n', rank_control_matrix);
if rank_control_matrix == n
    disp('The open loop system is controllable');
else
    disp('The open loop system is not controllable');
end


%% Q3 - Observability
fprintf('\n3. Observability\n\n')
C1 = [0 0 1 0 0]; % Output matrix for measuring x3 only
C2 = [1 0 0 0 0; 0 0 1 0 0]; % Output matrix for measuring x1 and x3

% Case 1: Only measuring x3 (pendulum angle)
observ_matrix_1 = obsv(A, C1);
rank_observ_matrix_1 = rank(observ_matrix_1);
fprintf('Case 1: Only measuring x3 (pendulum angle)\n');
disp('Observability Matrix:');
disp(observ_matrix_1);
fprintf('Rank of Observability Matrix: %d\n', rank_observ_matrix_1);
if rank_observ_matrix_1 == n
    disp('The state realization is observable');
else
    disp('The state realization is not observable');
end

% Case 2: Measuring x1 and x3
observ_matrix_2 = obsv(A, C2);
rank_observ_matrix_2 = rank(observ_matrix_2);
fprintf('\nCase 2: Measuring x1 and x3\n');
disp('Observability Matrix:');
disp(observ_matrix_2);
fprintf('Rank of Observability Matrix: %d\n', rank_observ_matrix_2);
if rank_observ_matrix_2 == n
    disp('The state realization is observable');
else
    disp('The state realization is not observable');
end

%% Q4 - Bode diagram of the open loop system
fprintf('\n4. Bode diagram of the open loop system\n\n')
% We can define three transfer functions with this state model (using the
% matrix C defined in the .mat file)

[num, den] = ss2tf(A,B,C,D);

fprintf('Transfer Function alpha(s)/u(s):\n')
G_alpha_u = tf(num(1, :), den)
fprintf('Transfer Function beta(s)/u(s):\n')
G_beta_u = tf(num(2, :), den)
fprintf('Transfer Function beta(s)/alpha(s):\n')
G_beta_alpha = tf(num(2, :), num(1, :))

range_frequencies = logspace(-2,4);

% Bode Plots
figure("name","Bode Plot of the Transfer Functions");
hold on;
bode(G_alpha_u, range_frequencies);
bode(G_beta_u, range_frequencies);
title("Bode Plot of the Transfer Functions", 'Interpreter', 'latex');
legend('$\alpha(s)/U(s)$','$\beta(s)/U(s)$','Interpreter', 'latex')
grid on;

%Pole-zero Plots
figure("name","Pole-zero Plot of the Transfer Function alpha(s)/u(s)");
hold on;
pzmap(G_alpha_u);
pzmap(G_beta_u);
title("Pole-zero Plot of the Transfer Functions", 'Interpreter', 'latex')
legend('$\alpha(s)/U(s)$','$\beta(s)/U(s)$','Interpreter', 'latex')
grid on;
axis equal;


%% Q5 - Vector of Gains of the Controller
fprintf('\n5. Vector of Gains of the Controller\n')

% Testing different values of Q1, Q3 and R with Q = [Q1, 0, Q3, 0, 0]
Q1_values = [1, 2, 10];
Q3_values = [1, 5, 1];
R_values = [1, 2, 1];  % R must be a positive semidefinite matrix

% Initialize the matrix to store the poles and the values of Q1, Q3, and R
poles_and_values_matrix = zeros(length(Q1_values), length(A) + 3); % +3 to include Q1, Q3, and R

for i = 1:length(Q1_values)
    Q1 = Q1_values(i);
    Q3 = Q3_values(i);
    R = R_values(i);

    Q = diag([Q1, 0, Q3, 0, 0]);
    K = lqr(A, B, Q, R); % % Calculate controller gain using LQR (Linear Quadratic Regulator)
    closed_loop_poles_controller = eig(A - B*K);
    poles_and_values_matrix(i, 1:3) = [Q1, Q3, R];
    poles_and_values_matrix(i, 4:end) = closed_loop_poles_controller';
end

column_names = {'Q1', 'Q3', 'R', 'Pole_1', 'Pole_2', 'Pole_3', 'Pole_4', 'Pole_5'};
table_poles_and_values = array2table(poles_and_values_matrix, 'VariableNames', column_names);
display(table_poles_and_values);

Q = diag([10, 0, 1, 0, 0]); % must be a positive semidefinite matrix 
R = 1; % must be a positive scalar (single input system)
K = lqr(A, B, Q, R); % Linear Quadratic Regulator
fprintf('K = ');
disp(K);
closed_loop_poles_controller = eig(A - B*K);
damp(A - B*K)

%% Q6 - Simulation of the Controlled System
x0 = [0.1 0 0 0 0]';
T = 2; % Time duration of the simulation
sim('Model1',T);

figure();
hold on;
grid on;
plot(t,x(:,[1 3]));
legend({"$\alpha$","$\beta$"},'Interpreter','latex');
xlabel("$t (\mathrm{s})$",'Interpreter','latex');

figure();
hold on;
grid on;
plot(t,x(:,[2 4]));
legend({"$\dot{\alpha}$","$\dot{\beta}$"},'Interpreter','latex');
xlabel("$t (\mathrm{s})$",'Interpreter','latex');

figure();
hold on;
grid on;
plot(t,u);
plot(t,x(:,5));
legend({"$u$","$i$"},'Interpreter','latex');
xlabel("$t (\mathrm{s})$",'Interpreter','latex');

figure();
gg=plot(t,x);
grid on;
set(gg,'LineWidth',1.2)
gg=xlabel('Time (s)');
set(gg,'Fontsize',14);
gg=ylabel('\beta (rad)');
set(gg,'Fontsize',14);


%% Q7 - Vector of Gains of the Observer
fprintf('\n7. Vector of Gains of the Observer\n')

G = eye(size(A));           % Gain of the process noise
Qe = eye(size(A))*10;       % Variance of process errors
Re = eye(2);                % Variance of measurement errors
L = lqe(A, G, C, Qe, Re);   % Calculate estimator gains

closed_loop_poles_observer = eig(A - L*C);
damp(A - L*C)


%% Q8 - Simulation of the Controlled System with the Observer
T = 4;
D = [0 0]';
D_ctl = [0 0];
sim('Model2',T);

figure();
gg=plot(t,y);
grid on;
set(gg,'LineWidth',1.2)
gg=xlabel('Time (s)');
set(gg,'Fontsize',14);
gg=ylabel('\beta (rad)');
set(gg,'Fontsize',14);

figure();
gg=plot(t,x);
grid on;
set(gg,'LineWidth',1.2)
gg=xlabel('Time (s)');
set(gg,'Fontsize',14);
gg=ylabel('\beta (rad)');
set(gg,'Fontsize',14);
